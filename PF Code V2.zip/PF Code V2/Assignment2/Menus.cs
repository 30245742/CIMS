﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    public class Menus
    {
        static List<Car> Cars = new List<Car>();
        public static int balance;
        public static int profit;
        public static List<string> GetFileLines(string filePath)
        {
            return File.ReadAllLines(filePath).ToList();
        }

        public static void AddCar()
        {
            //Call the variables
            string carmake;
            string cartype;
            string carmodel;
            int caryear;
            string carwheelSize;
            string carforks;
            int carsecurityCode;
            bool carcost;            
            string carcolor;

            //Gather details of new car
            Console.WriteLine("\nAdding a car to the inventory\n");

            Console.Write("Enter the make of the car: ");
            carmake = Console.ReadLine();  //store make

            Console.Write("Enter the type of the car: ");
            cartype = Console.ReadLine();  //store type

            Console.Write("Enter the model of the car: ");
            carmodel = Console.ReadLine(); //store model

            Console.Write("Enter the year of the car: ");
            caryear = int.Parse(Console.ReadLine());   //store year

            Console.Write("Enter the wheel size of the car: ");
            carwheelSize = Console.ReadLine(); //store wheel size

            Console.Write("Enter the type of forks of the car: ");
            carforks = Console.ReadLine(); //store forks

            Console.Write("Enter the security code of the car: ");
            carsecurityCode = int.Parse(Console.ReadLine()); //store security code  

            Console.Write("Enter the cost of the car: ");
            carcost = int.Parse(Console.ReadLine());  //store cost

            Console.Write("Enter the colour of the car: ");
            carcolor = Console.ReadLine(); //store colour

            //Store new car to inventory text file
            using (StreamWriter writer = new StreamWriter("inventory.txt", true))
            {
                writer.WriteLine("");
                writer.WriteLine(carmake);
                writer.WriteLine(cartype);
                writer.WriteLine(carmodel);
                writer.WriteLine(caryear);
                writer.WriteLine(carwheelSize);
                writer.WriteLine(carforks);
                writer.WriteLine(carsecurityCode);
                writer.WriteLine(carcost);
                writer.WriteLine(carcolor);
            }
            Console.WriteLine("\nCar added to the inventory.");
            Program.CarCounter = Program.CarCounter + 1; //+1 to inv count if car is added
            Program.MainMenu();
        }

        public static void ShowInventoryCount()
        {
            //display car counter created in program
            Console.Clear();
            Program.getInventory();
            Console.WriteLine("Number of cars in inventory: {0}", Program.CarCounter);
            Program.MainMenu();
        }

        public static void BuyCar()
        {
            Console.Clear();
            //Call the variables
            string sure;
            string carmake;
            string cartype;
            string carmodel;
            int caryear;
            string carwheelSize;
            string carforks;
            int carsecurityCode;
            int carcost;
            string carcolor;
            string carstatus;

            //Gather details of new car
            Console.WriteLine("\nBuying a car and adding it to the inventory\n");

            Console.Write("Enter the make of the car: ");
            carmake = Console.ReadLine();  //store make

            Console.Write("Enter the type of the car: ");
            cartype = Console.ReadLine();  //store type

            Console.Write("Enter the model of the car: ");
            carmodel = Console.ReadLine(); //store model

            Console.Write("Enter the year of the car: ");
            caryear = int.Parse(Console.ReadLine());   //store year

            Console.Write("Enter the wheel size of the car: ");
            carwheelSize = Console.ReadLine(); //store wheel size

            Console.Write("Enter the type of forks of the car: ");
            carforks = Console.ReadLine(); //store forks

            Console.Write("Enter the security code of the car: ");
            carsecurityCode = int.Parse(Console.ReadLine()); //store security code  

            Random random = new Random();
            int randomNumber = random.Next(1, 500);
            carcost = randomNumber;  //Randomly generates cost between 1 and 500

            Console.Write("Enter the colour of the car: ");
            carcolor = Console.ReadLine(); //store colour

            Console.WriteLine("");
            Console.WriteLine("New car costs: £" + carcost);
            Console.WriteLine("Current balance is: £" + balance);
            balance = balance - carcost;
            Console.WriteLine("If you buy the car your new balance will be: £" + balance);
            Console.WriteLine("Are you sure you want to buy it? (yes/no)");
            sure = Console.ReadLine();

            if (sure == "yes" || sure == "y" || sure == "Yes" || sure == "Y")
            {

                //Store new car to inventory text file
                using (StreamWriter writer = new StreamWriter("inventory.txt", true))
                {
                    writer.WriteLine("");
                    writer.WriteLine(carmake);
                    writer.WriteLine(cartype);
                    writer.WriteLine(carmodel);
                    writer.WriteLine(caryear);
                    writer.WriteLine(carwheelSize);
                    writer.WriteLine(carforks);
                    writer.WriteLine(carsecurityCode);
                    writer.WriteLine(carcost);
                    writer.WriteLine(carcolor);
                }

                carstatus = "Bought";
                //Store bought car to report text file
                using (StreamWriter writer = new StreamWriter("bsh.txt", true))
                {
                    writer.WriteLine("");
                    writer.WriteLine(carmake);
                    writer.WriteLine(carmodel);
                    writer.WriteLine(carsecurityCode);
                    writer.WriteLine(carcost);
                    writer.WriteLine(carstatus);
                }

                // read the current conent of the file into a list
                List<string> lines = File.ReadAllLines("bnp.txt").ToList();

                // update the list with the new balance and profit values
                lines[0] = balance.ToString();
                lines[1] = profit.ToString();

                // write the updated list back to the file
                File.WriteAllLines("bnp.txt", lines);

                Console.Clear();
                Console.WriteLine("\nCar bought and added to the inventory.");
                Program.CarCounter = Program.CarCounter + 1; //+1 to inv count if car is added
                Program.MainMenu();
            }
            else if (sure == "no" || sure == "n" || sure == "No" || sure == "N")
            {
                balance = balance + carcost;
                Console.Clear();
                Console.WriteLine("Returning to Menu");
                Console.WriteLine("");
                Program.MainMenu();
            }

            else //input validation
            {
                balance = balance + carcost;
                Console.Clear();
                Console.WriteLine("Input Invalid");
                Console.WriteLine("Press any key...");
                Console.ReadKey();
                BuyCar();
            }
        }
        public static void ShowInv()
        {
            //display cars in inventory
            Console.Clear();
            Program.displayCar();
            Program.MainMenu();
        }

        public static void ProduceReport()
        {
            //display cars report
            Console.Clear();
            Program.MainMenu();
        }
        public static void Money() 
        {
            int tempbalance;
            int tempprofit;
            string sure;

            Console.Clear();

            Console.WriteLine("Current balance £" + balance);
            Console.WriteLine("Current profit £" + profit);
            Console.WriteLine("");
            Console.WriteLine("Enter new balance");
            tempbalance = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter new profit");
            tempprofit = int.Parse(Console.ReadLine());
            Console.WriteLine("");
            Console.WriteLine("This will change the balance to £" + tempbalance + " and the profit to £" + tempprofit);
            Console.WriteLine("Are you sure you want to change it? (yes/no)");
            sure = Console.ReadLine();

            if (sure == "yes" || sure == "y" || sure == "Yes" || sure == "Y")
            {

                balance = tempbalance;
                profit = tempprofit;
                // read the current conent of the file into a list
                List<string> lines = File.ReadAllLines("bnp.txt").ToList();

                // update the list with the new balance and profit values
                lines[0] = balance.ToString();
                lines[1] = profit.ToString();

                // write the updated list back to the file
                File.WriteAllLines("bnp.txt", lines);

                Console.Clear();
                Console.WriteLine("\nBalance and profit updated.");
                Console.WriteLine("Press any key...");
                Console.ReadKey();
                Program.MainMenu();
            }
            else if (sure == "no" || sure == "n" || sure == "No" || sure == "N")
            {
                Console.Clear();
                Console.WriteLine("Returning to Menu");
                Console.WriteLine("");
                Program.MainMenu();
            }

            else //input validation
            {
                Console.Clear();
                Console.WriteLine("Input Invalid");
                Console.WriteLine("Press any key...");
                Console.ReadKey();
                Money();
            }

        }
    }
}
