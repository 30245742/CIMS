﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    public class Menus
    {
        static List<Car> Cars = new List<Car>();
        public static int balance;
        public static int profit;
        public static List<string> GetFileLines(string filePath)
        {
            return File.ReadAllLines(filePath).ToList();
        }

        public static void AddCar()
        {
            //Call the variables
            string carmake;
            string cartype;
            string carmodel;
            int caryear;
            string carwheelSize;
            string carforks;
            int carsecurityCode;
            int carcost;
            string carcolor;

            //Gather details of new car
            Console.WriteLine("\nAdding a car to the inventory\n");

            Console.Write("Enter the make of the car: ");
            carmake = Console.ReadLine();  //store make

            Console.Write("Enter the type of the car: ");
            cartype = Console.ReadLine();  //store type

            Console.Write("Enter the model of the car: ");
            carmodel = Console.ReadLine(); //store model

            Console.Write("Enter the year of the car: ");
            caryear = int.Parse(Console.ReadLine());   //store year

            Console.Write("Enter the wheel size of the car: ");
            carwheelSize = Console.ReadLine(); //store wheel size

            Console.Write("Enter the type of forks of the car: ");
            carforks = Console.ReadLine(); //store forks

            Console.Write("Enter the security code of the car: ");
            carsecurityCode = int.Parse(Console.ReadLine()); //store security code  

            Console.Write("Enter the cost of the car: ");
            carcost = int.Parse(Console.ReadLine());  //store cost

            Console.Write("Enter the colour of the car: ");
            carcolor = Console.ReadLine(); //store colour

            //Store new car to inventory text file
            using (StreamWriter writer = new StreamWriter("inventory.txt", true))
            {
                writer.WriteLine("");
                writer.WriteLine(carmake);
                writer.WriteLine(cartype);
                writer.WriteLine(carmodel);
                writer.WriteLine(caryear);
                writer.WriteLine(carwheelSize);
                writer.WriteLine(carforks);
                writer.WriteLine(carsecurityCode);
                writer.WriteLine(carcost);
                writer.WriteLine(carcolor);
            }
            Console.WriteLine("\nCar added to the inventory.");
            Program.CarCounter = Program.CarCounter + 1; //+1 to inv count if car is added
            Program.MainMenu();
        }
    }
}