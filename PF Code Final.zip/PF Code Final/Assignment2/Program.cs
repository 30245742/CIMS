﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Security.Authentication.ExtendedProtection;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;


namespace Assignment2
{
    class Program
    {
        public static bool CountCheck = false; //Count check sets to true once the menu loads so it doesn't duplicate the count.
        public static void MainMenu()
        {
            CountCheck = true; //stops counter duplicating
            getInventory(); //refresh inventory before loading menu
            getReport(); //refresh report before loading menu
            //Main Menu options
            Console.WriteLine("\nCar Inventory Management System\n");

            //Read line 1 from text file and set as balance
            List<string> lines = File.ReadAllLines("bnp.txt").ToList();
            Menus.balance = int.Parse(lines[0]);
            Console.WriteLine("Current Balance: £" + Menus.balance);

            //Read line 2 from text file and set as profit
            List<string> lines1 = File.ReadAllLines("bnp.txt").ToList();
            Menus.profit = int.Parse(lines[1]);
            Console.WriteLine("Current Profit: £" + Menus.profit);
            Console.WriteLine("");

            Console.WriteLine("1. Show the number of cars in the inventory");
            Console.WriteLine("2. Buy a car");
            Console.WriteLine("3. Sell a car");
            Console.WriteLine("4. Hire a car");
            Console.WriteLine("5. Show the inventory");
            Console.WriteLine("6. Produce a report for cars bought, sold and hired");
            Console.WriteLine("7. Quit");
            Console.WriteLine("For admin access please enter password");

            Console.Write("\nEnter your choice (1-6): ");
            string input = Console.ReadLine();

            switch (input)
            {
                case "1":
                    Menus.ShowInventoryCount();
                    break;
                case "2":
                    Menus.BuyCar();
                    break;
                case "3":
                    SellCar();
                    break;
                case "4":
                    HireCar();
                    break;
                case "5":
                    Menus.ShowInv();
                    break;
                case "6":
                    Menus.ProduceReport();
                    break;
                case "7":
                    Environment.Exit(0);
                    break;
                case "c":
                    Console.Clear();
                    MainMenu();
                    break;
                case "ADMIN":
                    Console.Clear();
                    Admin();
                    break;
                default:
                    Console.WriteLine("Invalid choice. Please try again.");
                    Console.WriteLine("Press any key...");
                    Console.ReadKey();
                    MainMenu();
                    break;
            }
        }
        //Admin Panel
        public static void Admin()
        {
            Console.Clear();
            Console.WriteLine("\nCar Inventory Management System\n");
            Console.WriteLine(@"
*ADMIN PANEL*
");
            Console.WriteLine("1. Add a car to the inventory");
            Console.WriteLine("2. Remove a car from the inventory");
            Console.WriteLine("3. Edit a car in the inventory");
            Console.WriteLine("4. Manually edit Balance and Profit");
            Console.WriteLine("5. Back to Main Menu");
            Console.WriteLine("6. Quit");

            Console.Write("\nEnter your choice (1-6): ");
            string input = Console.ReadLine();

            switch (input)
            {
                case "1":
                    Menus.AddCar();
                    break;
                case "2":
                    RemoveCar();
                    break;
                case "3":
                    EditCar();
                    break;
                case "4":
                    Menus.Money();
                    break;
                case "5":
                    Console.Clear();
                    MainMenu();
                    break;
                case "6":
                    Environment.Exit(0);
                    break;
                case "c":
                    Console.Clear();
                    MainMenu();
                    break;
                default:
                    Console.WriteLine("Invalid choice. Please try again.");
                    Console.WriteLine("Press any key...");
                    Console.ReadKey();
                    Admin();
                    break;
            }
        }

        static List<Car> Cars = new List<Car>();
        static List<hirecar> hirecars = new List<hirecar>();
        public static int CarCounter = 0;
        public static void Main(string[] args)
        {
            getInventory(); //call the method to get the cars from the inventory file
            getReport();
            MainMenu();

            Console.ReadLine();
        }

        public static void getInventory() //method to get the cars from the inventory file
        {
            Cars.Clear(); //clear the cars list before adding new cars
            //read the file into a text string
            string[] lines = System.IO.File.ReadAllLines(@"inventory.txt");

            int invCounter = 0;

            int invLength = lines.Length / 10; //works out the number of cars in the inventory.txt file

            for (int i = 0; i <= invLength; i++) //for each car
            {
                string make = lines[i * 10 + invCounter]; //store the make
                string type = lines[i * 10 + invCounter + 1]; //store the type
                string model = lines[i * 10 + invCounter + 2]; //store the model
                int year = int.Parse(lines[i * 10 + invCounter + 3]); //store the year
                string wheelSize = lines[i * 10 + invCounter + 4]; //store the wheel size
                string frameType = lines[i * 10 + invCounter + 5]; //store the frame type
                int securityCode = int.Parse(lines[i * 10 + invCounter + 6]); //store the security code
                int cost = int.Parse(lines[i * 10 + invCounter + 7]); //store the cost
                string color = lines[i * 10 + invCounter + 8]; //store the frame type

                // Reset invCounter after each car
                invCounter = 0;

                Car cr = new Car(make, type, model, year, wheelSize, frameType, securityCode, cost, color); //create a new car object with the details stored above
                Cars.Add(cr); //add the car to Cars list

                //Counts cars in inventory
                if (CountCheck == false)
                {
                    CarCounter++;
                }

            }
        }
        public static void displayCar() //display the inventory (Car list) to the screen
        {
            foreach (Car cr in Cars)
            {
                Console.WriteLine("Type: {0,-10}\t Code: {1,-10}\t Make: {2,-10}\t Model: {3,-10}\t Year: {4,-5}\t WheelSize: {5,-5}\t Forks: {6,-25}\t Cost: £{7}\t Color: {8,-5}", cr.Type, cr.SecurityCode, cr.Make, cr.Model, cr.Year, cr.WheelSize, cr.Forks, cr.Cost, cr.Color);
            }
        }

        //store bought, sold and hired
        public static void getReport() //method to get the cars from the inventory file
        {
            hirecars.Clear(); //clear the cars list before adding new cars
            //read the file into a text string
            string[] lines = System.IO.File.ReadAllLines(@"bsh.txt");

            int invCounter = 0;

            int invLength = lines.Length / 6; //works out the number of cars in the inventory.txt file

            for (int i = 0; i <= invLength; i++) //for each car
            {
                string make = lines[i * 6 + invCounter]; //store the make
                string model = lines[i * 6 + invCounter + 1]; //store the model
                int securityCode = int.Parse(lines[i * 6 + invCounter + 2]); //store the security code
                int cost = int.Parse(lines[i * 6 + invCounter + 3]); //store the cost/profit
                string status = lines[i * 6 + invCounter + 4]; //store the status


                // Reset invCounter after each car
                invCounter = 0;

                hirecar hb = new hirecar(make, model, securityCode, cost, status); //create a new car object with the details stored above
                hirecars.Add(hb); //add the car to cars list


            }
        }
        public static void displayBSH() //display the bought, sold and hired (cars list) to the screen
        {
            foreach (hirecar hb in hirecars)
            {
                Console.WriteLine("Make: {0,-10}\t Model: {1,-10}\t Code: {2,-10}\t Buy,Sell or Hire Price: £{3}\t Status: {4,-5}", hb.Make, hb.Model, hb.SecurityCode, hb.Cost, hb.Status);
            }
        }



        //Remove, Edit, Sell and Hire car methods are placed in here rather than the Menus class as they need to validate security code.

        public static void RemoveCar()
        {
            //Asks for security code for car to remove
            Console.Clear();
            Console.WriteLine("Enter the security code of the car you want to remove:");
            int removeSecurityCode = int.Parse(Console.ReadLine());

            bool carFound = false;
            for (int i = 0; i < Cars.Count; i++)
            {
                if (Cars[i].SecurityCode == removeSecurityCode)
                {
                    Cars.RemoveAt(i);
                    Console.WriteLine("Car removed successfully.");

                    // Rewrite the entire inventory file with the updated car list
                    using (StreamWriter writer = new StreamWriter("inventory.txt"))
                    {
                        for (int j = 0; j < Cars.Count; j++)
                        {
                            writer.WriteLine(Cars[j].Make);
                            writer.WriteLine(Cars[j].Type);
                            writer.WriteLine(Cars[j].Model);
                            writer.WriteLine(Cars[j].Year);
                            writer.WriteLine(Cars[j].WheelSize);
                            writer.WriteLine(Cars[j].Forks);
                            writer.WriteLine(Cars[j].SecurityCode);
                            writer.WriteLine(Cars[j].Cost);
                            writer.WriteLine(Cars[j].Color);
                            if (j != Cars.Count - 1) //Removes blank line at the end
                            {
                                writer.WriteLine("");
                            }
                        }
                    }

                    carFound = true;
                    CarCounter = CarCounter - 1; //-1 from inv count if car is removed
                    break;
                }
            }
            //input validation
            if (!carFound)
            {
                Console.WriteLine("Car with security code {0} not found in inventory.", removeSecurityCode);
            }

            Admin();
        }

        public static void EditCar()
        {
            //edits car using security code (Security code cannot be edited)
            Console.Clear();
            Console.WriteLine("Enter the security code of the car you want to edit:");
            int editSecurityCode = int.Parse(Console.ReadLine());

            bool carFound = false;
            for (int i = 0; i < Cars.Count; i++)
            {
                if (Cars[i].SecurityCode == editSecurityCode)
                {
                    //Edited details for car
                    Console.WriteLine("Enter the new details for the car:");

                    Console.Write("Make: ");
                    string make = Console.ReadLine();

                    Console.Write("Type: ");
                    string type = Console.ReadLine();

                    Console.Write("Model: ");
                    string model = Console.ReadLine();

                    Console.Write("Year: ");
                    int year = int.Parse(Console.ReadLine());

                    Console.Write("Wheel Size: ");
                    string wheelSize = Console.ReadLine();

                    Console.Write("Frame Type: ");
                    string frameType = Console.ReadLine();

                    Console.Write("Cost: ");
                    int cost = int.Parse(Console.ReadLine());

                    Console.Write("Color: ");
                    string color = Console.ReadLine();

                    // Update the car details
                    Cars[i].Make = make;
                    Cars[i].Type = type;
                    Cars[i].Model = model;
                    Cars[i].Year = year;
                    Cars[i].WheelSize = wheelSize;
                    Cars[i].Forks = frameType;
                    Cars[i].Cost = cost;
                    Cars[i].Color = color;

                    Console.WriteLine("Car details updated successfully.");

                    // Rewrite the entire inventory file with the updated car list
                    using (StreamWriter writer = new StreamWriter("inventory.txt"))
                    {
                        for (int j = 0; j < Cars.Count; j++)
                        {
                            writer.WriteLine(Cars[j].Make);
                            writer.WriteLine(Cars[j].Type);
                            writer.WriteLine(Cars[j].Model);
                            writer.WriteLine(Cars[j].Year);
                            writer.WriteLine(Cars[j].WheelSize);
                            writer.WriteLine(Cars[j].Forks);
                            writer.WriteLine(Cars[j].SecurityCode);
                            writer.WriteLine(Cars[j].Cost);
                            writer.WriteLine(Cars[j].Color);
                            if (j != Cars.Count - 1) //Removes blank line at the end
                            {
                                writer.WriteLine(" ");
                            }
                        }
                    }
                    carFound = true;
                    MainMenu();
                    break;
                }
            }
            //input validation
            if (!carFound)
            {
                Console.WriteLine("Car with security code {0} not found in inventory.", editSecurityCode);
                MainMenu();
            }
        }
        public static void SellCar()
        {
            int buycost;
            string sure;
            int sellcost;
            int cprofit;
            string carmake;
            string carmodel;
            int carsecurityCode;
            string status = "Sold";

            //Asks for security code for car to sell
            Console.Clear();
            Console.WriteLine("Enter the security code of the car you want to sell:");
            int removeSecurityCode = int.Parse(Console.ReadLine());

            //Set the car cost using the security code
            var car = Cars.FirstOrDefault(b => b.SecurityCode == removeSecurityCode);
            if (car == null)
            {
                Console.WriteLine("Car with security code {0} not found in inventory.", removeSecurityCode);
                SellCar();
                return;
            }

            carmake = car.Make;
            carmodel = car.Model;
            carsecurityCode = car.SecurityCode;
            buycost = car.Cost;

            bool carFound = false;
            for (int i = 0; i < Cars.Count; i++)
            {
                if (Cars[i].SecurityCode == removeSecurityCode)
                {
                    Cars.RemoveAt(i);
                    Console.WriteLine("Cars found successfully.");
                    Console.WriteLine("");
                    Console.WriteLine("This car was bought for: £" + buycost);

                    //work out sell price (random)
                    Random random = new Random();
                    int randomNumber = random.Next(1, 350);
                    sellcost = buycost + randomNumber;
                    cprofit = sellcost - buycost;

                    Console.WriteLine("The customer has agreed to buy this car for: £" + sellcost);
                    Console.WriteLine("The sale will generate: £" + cprofit + " profit");
                    Console.WriteLine("");
                    Console.WriteLine("Current balance is: £" + Menus.balance);
                    Menus.balance = Menus.balance + sellcost;
                    Console.WriteLine("Balance after sale will be: £" + Menus.balance);
                    Menus.profit = Menus.profit + cprofit;
                    Console.WriteLine("Total profits after sale will be: £" + Menus.profit);

                    Console.WriteLine("Are you sure you want to complete the sale? (yes/no)");
                    sure = Console.ReadLine();

                    if (sure == "yes" || sure == "y" || sure == "Yes" || sure == "Y")
                    {

                        // Rewrite the entire inventory file with the updated car list
                        using (StreamWriter writer = new StreamWriter("inventory.txt"))
                        {
                            for (int j = 0; j < Cars.Count; j++)
                            {
                                writer.WriteLine(Cars[j].Make);
                                writer.WriteLine(Cars[j].Type);
                                writer.WriteLine(Cars[j].Model);
                                writer.WriteLine(Cars[j].Year);
                                writer.WriteLine(Cars[j].WheelSize);
                                writer.WriteLine(Cars[j].Forks);
                                writer.WriteLine(Cars[j].SecurityCode);
                                writer.WriteLine(Cars[j].Cost);
                                writer.WriteLine(Cars[j].Color);
                                if (j != Cars.Count - 1) //Removes blank line at the end
                                {
                                    writer.WriteLine("");
                                }
                            }
                        }

                        //Store sold car to report text file
                        using (StreamWriter writer = new StreamWriter("bsh.txt", true))
                        {
                            writer.WriteLine("");
                            writer.WriteLine(carmake);
                            writer.WriteLine(carmodel);
                            writer.WriteLine(carsecurityCode);
                            writer.WriteLine(sellcost);
                            writer.WriteLine(status);
                        }

                        // read the current conent of the file into a list
                        List<string> lines = File.ReadAllLines("bnp.txt").ToList();

                        // update the list with the new balance and profit values
                        lines[0] = Menus.balance.ToString();
                        lines[1] = Menus.profit.ToString();

                        // write the updated list back to the file
                        File.WriteAllLines("bnp.txt", lines);

                        carFound = true;
                        Console.WriteLine("Car sold successfully.");
                        CarCounter = CarCounter - 1; //-1 from inv count if car is removed
                        break;
                    }
                    else if (sure == "no" || sure == "n" || sure == "No" || sure == "N")
                    {
                        Menus.balance = Menus.balance - sellcost;
                        Menus.profit = Menus.profit - cprofit;
                        Console.Clear();
                        Console.WriteLine("Returning to Menu");
                        Console.WriteLine("");
                        Program.MainMenu();
                    }
                    else //input validation
                    {
                        Menus.balance = Menus.balance + sellcost;
                        Menus.profit = Menus.profit - cprofit;
                        Console.Clear();
                        Console.WriteLine("Input Invalid");
                        Console.WriteLine("Press any key...");
                        Console.ReadKey();
                        SellCar();
                    }
                }
            }
            //input validation
            if (!carFound)
            {
                Console.WriteLine("Car with security code {0} not found in inventory.", removeSecurityCode);
            }

            MainMenu();
        }

        public static string bmake;
        public static string btype;
        public static string bmodel;
        public static int byear;
        public static string bwheelSize;
        public static string bforks;
        public static int bsecurityCode;
        public static int bcost;
        public static string bcolor;
        public static void HireCar()
        {
            int buycost;
            string sure;
            string carmake1;
            string carmodel1;
            int carsecurityCode1;
            string status = "Hired";
            int hirelength;

            //asks whether user wants to hire a car out or return a hired car back in.
            Console.Clear();
            Console.WriteLine("1. Hire a car out");
            Console.WriteLine("2. Return a previously hired car");
            Console.WriteLine("3. Return to Menu");

            Console.Write("\nEnter your choice (1-3): ");
            string input = Console.ReadLine();

            switch (input)
            {
                case "1":
                    //Asks for security code for car to hire
                    Console.Clear();
                    Console.WriteLine("Enter the security code of the car you want to hire out:");
                    int removeSecurityCode = int.Parse(Console.ReadLine());

                    //Stores the car deatils using the security code
                    var car = Cars.FirstOrDefault(b => b.SecurityCode == removeSecurityCode);
                    if (car == null)
                    {
                        Console.WriteLine("Car with security code {0} not found in inventory.", removeSecurityCode);
                        HireCar();
                        return;
                    }

                    carmake1 = car.Make;
                    carmodel1 = car.Model;
                    carsecurityCode1 = car.SecurityCode;
                    buycost = car.Cost;
                    bmake = car.Make;
                    btype = car.Type;
                    bmodel = car.Model;
                    byear = car.Year;
                    bwheelSize = car.WheelSize;
                    bforks = car.Forks;
                    bsecurityCode = car.SecurityCode;
                    bcost = car.Cost;
                    bcolor = car.Color;

                    bool carFound = false;
                    for (int i = 0; i < Cars.Count; i++)
                    {
                        if (Cars[i].SecurityCode == removeSecurityCode)
                        {
                            Cars.RemoveAt(i);
                            Console.WriteLine("Car found successfully.");
                            Console.WriteLine("");
                            Console.WriteLine("How many days will you be hiring this car for?");
                            hirelength = int.Parse(Console.ReadLine());


                            Console.WriteLine("Hiring this car out will earn: £" + hirelength);
                            Console.WriteLine("");
                            Console.WriteLine("Current balance is: £" + Menus.balance);
                            Menus.balance = Menus.balance + hirelength;
                            Console.WriteLine("Balance after hiring out will be: £" + Menus.balance);
                            Console.WriteLine("Current profit is: £" + Menus.profit);
                            Menus.profit = Menus.profit + hirelength;
                            Console.WriteLine("Total profits after hiring out will be: £" + Menus.profit);

                            Console.WriteLine("Are you sure you want to complete the sale? (yes/no)");
                            sure = Console.ReadLine();

                            if (sure == "yes" || sure == "y" || sure == "Yes" || sure == "Y")
                            {

                                // Rewrite the entire inventory file with the updated car list
                                using (StreamWriter writer = new StreamWriter("inventory.txt"))
                                {
                                    for (int j = 0; j < Cars.Count; j++)
                                    {
                                        writer.WriteLine(Cars[j].Make);
                                        writer.WriteLine(Cars[j].Type);
                                        writer.WriteLine(Cars[j].Model);
                                        writer.WriteLine(Cars[j].Year);
                                        writer.WriteLine(Cars[j].WheelSize);
                                        writer.WriteLine(Cars[j].Forks);
                                        writer.WriteLine(Cars[j].SecurityCode);
                                        writer.WriteLine(Cars[j].Cost);
                                        writer.WriteLine(Cars[j].Color);
                                        if (j != Cars.Count - 1) //Removes blank line at the end
                                        {
                                            writer.WriteLine("");
                                        }
                                    }
                                }

                                //Store sold car to report text file
                                using (StreamWriter writer = new StreamWriter("bsh.txt", true))
                                {
                                    writer.WriteLine("");
                                    writer.WriteLine(carmake1);
                                    writer.WriteLine(carmodel1);
                                    writer.WriteLine(carsecurityCode1);
                                    writer.WriteLine(hirelength);
                                    writer.WriteLine(status);
                                }

                                // read the current conent of the file into a list
                                List<string> lines = File.ReadAllLines("bnp.txt").ToList();

                                // update the list with the new balance and profit values
                                lines[0] = Menus.balance.ToString();
                                lines[1] = Menus.profit.ToString();

                                // write the updated list back to the file
                                File.WriteAllLines("bnp.txt", lines);

                                carFound = true;
                                Console.WriteLine("Car hired out successfully.");
                                CarCounter = CarCounter - 1; //-1 from inv count if car is removed
                                break;
                            }
                            else if (sure == "no" || sure == "n" || sure == "No" || sure == "N")
                            {
                                Menus.balance = Menus.balance - hirelength;
                                Menus.profit = Menus.profit - hirelength;
                                Console.Clear();
                                Console.WriteLine("Returning to Menu");
                                Console.WriteLine("");
                                Program.MainMenu();
                            }
                            else //input validation
                            {
                                Menus.balance = Menus.balance - hirelength;
                                Menus.profit = Menus.profit - hirelength;
                                Console.Clear();
                                Console.WriteLine("Input Invalid");
                                Console.WriteLine("Press any key...");
                                Console.ReadKey();
                                SellCar();
                            }
                        }
                    }
                    //input validation
                    if (!carFound)
                    {
                        Console.WriteLine("Car with security code {0} not found in inventory.", removeSecurityCode);
                    }

                    MainMenu();
                    break;

                case "2":

                    Console.WriteLine("Enter the security code of the car you want to return from hire:");
                    int returnSecurityCode = int.Parse(Console.ReadLine());

                    for (int i = 0; i < hirecars.Count; i++)
                    {
                        if (hirecars[i].SecurityCode == returnSecurityCode)
                        {
                            hirecars.RemoveAt(i);
                            Console.WriteLine("Cars returned successfully.");

                            // Rewrite the entire inventory file with the updated car list
                            using (StreamWriter writer = new StreamWriter("bsh.txt"))
                            {
                                for (int j = 0; j < hirecars.Count; j++)
                                {
                                    writer.WriteLine(hirecars[j].Make);
                                    writer.WriteLine(hirecars[j].Model);
                                    writer.WriteLine(hirecars[j].SecurityCode);
                                    writer.WriteLine(hirecars[j].Cost);
                                    writer.WriteLine(hirecars[j].Status);
                                    if (j != hirecars.Count - 1) //Removes blank line at the end
                                    {
                                        writer.WriteLine("");
                                    }
                                }
                            }
                        }
                    }

                    //puts the returned car back to the inventory text file
                    using (StreamWriter writer = new StreamWriter("inventory.txt", true))
                    {
                        writer.WriteLine("");
                        writer.WriteLine(bmake);
                        writer.WriteLine(btype);
                        writer.WriteLine(bmodel);
                        writer.WriteLine(byear);
                        writer.WriteLine(bwheelSize);
                        writer.WriteLine(bforks);
                        writer.WriteLine(bsecurityCode);
                        writer.WriteLine(bcost);
                        writer.WriteLine(bcolor);
                    }

                    CarCounter = CarCounter + 1;

                    MainMenu();
                    break;
                case "3":
                    MainMenu();
                    break;
            }
        }
    }
}